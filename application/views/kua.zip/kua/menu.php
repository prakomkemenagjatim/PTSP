<header id="header" class="header fixed-top d-flex align-items-center">
    <div class="container-fluid d-flex align-items-center justify-content-between">

      <a style="color:#000 !important" href="/" class="logo d-flex align-items-center me-auto me-xl-0">
        <!-- Uncomment the line below if you also wish to use an image logo -->
        <!-- <img src="assets/img/logo.png" alt=""> -->
        <h >KUA Keren</h1>
        <span>.</span>
      </a>

      <!-- Nav Menu -->
      <nav id="navmenu" class="navmenu">
        <ul>
          <li><a href="/" class="active">Beranda</a></li>
          <li><a href="../../index.php/home#faq">Alur</a></li>
          <li><a href="../../index.php/home#services">Layanan</a></li>
          <li><a href="../../index.php/kua">KUA</a></li>
            <li><a href="../../index.php/madrasah">Madrasah</a></li>
         
          <li><a href="../../index.php/home#contact">Buku Tamu</a></li>
        </ul>

        <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
      </nav><!-- End Nav Menu -->

      <a class="btn-getstarted" href="../../dashboard/index.php/login">Login</a>

    </div>
  </header><!-- End Header -->